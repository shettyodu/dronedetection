#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2018 gr-MachineLearning author.
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy
from gnuradio import gr
import pickle
import pandas as pd

class ML_Testing(gr.basic_block):
    """
    docstring for block ML_Testing
    """
    def __init__(self, data_path, model_name):
        gr.basic_block.__init__(self,
            name="ML_Testing",
            in_sig=None,
            out_sig=None)
	self.data_path = data_path
        self.model_name = model_name
        self.test(self.data_path, self.model_name)
    """
    def forecast(self, noutput_items, ninput_items_required):
        #setup size of input_items[i] for work call
        for i in range(len(ninput_items_required)):
            ninput_items_required[i] = noutput_items

    def general_work(self, input_items, output_items):
        output_items[0][:] = input_items[0]
        consume(0, len(input_items[0]))
        #self.consume_each(len(input_items[0]))
        return len(output_items[0])
    """
    def test(self, path, model):
        data = pd.read_csv(path, header=None)
        x_test = data.values[:, 0:data.shape[1]]
        #x_test = data.values[:, 1:data.shape[1]]
	#y_test = data.values[:, 0]
	
	# load the model from disk
	filename = '/home/cssdr/ML_Models/'+model
	loaded_model = pickle.load(open(filename, 'rb'))
	predicted = loaded_model.predict(x_test)
	#result = loaded_model.score(x_test, y_test)
	print('The predicted class is %s' %predicted)
	#print('Classification Accuracy = %f' %result)
